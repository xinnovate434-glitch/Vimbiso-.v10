# Vimbiso Network

A mobile-first prototype for Vimbiso Network — a real-time trading marketplace (buyers, traders, and delivery riders) built for Zimbabwe, with USSD fallback for feature phones.

## Run it locally
Just open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000

## Deploy to GitHub Pages
1. Push this repo to GitHub.
2. Go to Settings → Pages.
3. Set the source branch to `main` (or `master`) and folder to `/ (root)`.
4. Your site will be live at `https://<username>.github.io/<repo-name>/`.

## Structure
- `index.html` — the entire app (HTML, CSS, JS in one self-contained file). No build step required.
